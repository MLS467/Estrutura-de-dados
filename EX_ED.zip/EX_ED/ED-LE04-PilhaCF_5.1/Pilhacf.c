#include <stdio.h>
#include <stdlib.h>
#include "pilhacf.h"

void criaPilha(PilhaCF *pl){
     pl->topo = -1;
}

void exibePilha(PilhaCF pl){
  int i;
  for(i=0; i<=pl.topo; i++){
  	printf("%d. CODIGO: %d - PESO: %.3f\n", i+1, pl.v[i].cod, pl.v[i].peso);

  }
}

int empilha(PilhaCF *pl, Dado dado){
	if(pl->topo == MAX_NODOS-1){
 	return (PILHA_CHEIA);
	}else{
	pl->topo ++;
 	pl->v[pl->topo] = dado;
	 return (SUCESSO); 
	}
}

int desempilha(PilhaCF *pl, Dado *dado){
	 if(pl->topo == -1){
	 	return PILHA_VAZIA;
	 }else{
	 *dado = pl->v[pl->topo];
	  pl->topo--;
	 return SUCESSO;
	 }
	 
}

int estaVazia(PilhaCF *pl){
	if(pl->topo == -1){
		return PILHA_VAZIA;
	}else{
		return SUCESSO;
	}
}

int consultaTopo(PilhaCF *pl, Dado *dado){
	
	if(pl->topo == -1){
		return PILHA_VAZIA;
	}else{
		*dado = pl->v[pl->topo];
		return SUCESSO;
	}
	
}


int pesquisa(PilhaCF *pl, int d){
     int i, c=0;
	if(pl->topo == -1){
		return PILHA_VAZIA;
			
	}else if(pl->topo >= 0){
		for(i = 0 ; i <= pl->topo; i++){
			if(pl->v[i].cod == d){	
			 printf("%d. CODIGO: %d - PESO: %.3f\n", i+1,pl->v[i].cod, pl->v[i].peso);
			 return SUCESSO;
			}
		}
	}else{
		return DADO_INEXISTENTE;
	}
}




