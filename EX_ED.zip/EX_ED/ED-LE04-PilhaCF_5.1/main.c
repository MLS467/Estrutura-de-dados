#include <stdio.h>
#include <stdlib.h>
#include "Pilhacf.h"

main() {
    int op;
    PilhaCF pl;
    int d;
    Dado dado;

    criaPilha(&pl);

    do {
        printf("\n0. SAIR\n");
        printf("1. EMPILHAR\n");
        printf("2. DESEMPILHAR\n");
        printf("3. VERIFICAR SE ESTA VAZIA\n");
        printf("4. CONSULTAR O TOPO\n");
        printf("5. EXIBIR A PILHA\n");
        printf("6. PESQUISAR\n");
        printf("Operacao: ");
        scanf("%d", &op);

        switch (op) {
            case 1:
                if (empilha(&pl, pl.v[pl.topo]) == PILHA_CHEIA) {
                    printf("A PILHA ESTA CHEIA.\n");
                } else {
                    printf("Insira o codigo: ");
                    scanf("%d", &pl.v[pl.topo].cod);
                    fflush(stdin);
                    printf("Insira o peso: ");
                    scanf("%f", &pl.v[pl.topo].peso);
                    printf("VALOR ADICIONADO COM SUCESSO.\n");
                }
                break;
            case 2:
                if (desempilha(&pl, &dado) == PILHA_VAZIA) {
                    printf("A PILHA ESTA VAZIA.\n");
                } else {
                    printf("O VALOR %.2f DE COD.%d FOI RETIRADO.\n", dado.peso, dado.cod);
                }
                break;
            case 3:
                if (estaVazia(&pl) == PILHA_VAZIA) {
                    printf("A PILHA ESTA VAZIA.\n");
                } else {
                    printf("A PILHA NAO ESTA VAZIA.\n");
                }
                break;
            case 4:
                if (consultaTopo(&pl, &dado) == PILHA_VAZIA) {
                    printf("A PILHA ESTA VAZIA.\n");
                } else {
                    printf("CONSULTA BEM-SUCEDIDA.\n");
                    printf("COD %d, PESO %.2f\n", dado.cod, dado.peso);
                }
                break;
            case 5:
                exibePilha(pl);
                break;
            case 6:
                printf("Insira o codigo a ser pesquisado: ");
                scanf("%d", &d);
                if (pesquisa(&pl, d) == PILHA_VAZIA) {
                    printf("A PILHA ESTA VAZIA.\n");
                } else if (pesquisa(&pl, d) == SUCESSO) {
                    printf("\nCODIGO ENCONTRADO.\n");
                } else {
                    printf("DADO INEXISTENTE.\n");
                }
                break;
        }
    } while (op != 0);

   
}

