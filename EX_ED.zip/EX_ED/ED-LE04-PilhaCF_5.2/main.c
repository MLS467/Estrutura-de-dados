#include <stdio.h>
#include "pilhacf.h"


main() {
    Pilha pilha;
    criaPilha(&pilha);

    int opcao, codigoPesquisa, codigo;
    Dado dado;
    float peso;

    do {
        printf("\n0. Fim\n");
        printf("1. Empilha\n");
        printf("2. Desempilha\n");
        printf("3. Quantidade de nodos\n");
        printf("4. Exibe situacao da pilha\n");
        printf("5. Consulta topo\n");
        printf("6. Pesquisa codigo\n");
        printf("Operacao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Insira o codigo: ");
                scanf("%d", &codigo);
                printf("Insira o peso: ");
                scanf("%f", &peso);
                if (empilha(&pilha, codigo, peso) == SUCESSO) {
                    printf("Empilhado com SUCESSO.\n");
                } else {
                    printf("A pilha esta cheia.\n");
                }
                break;
            case 2:
                if (desempilha(&pilha, &dado) == SUCESSO) {
                    printf("Desempilhado com SUCESSO. CODIGO: %d - PESO: %.2f\n", dado.codigo, dado.peso);
                } else {
                    printf("A pilha esta vazia.\n");
                }
                break;
            case 3:
                printf("Quantidade de nodos na pilha: %d\n", quantidadeNodos(&pilha));
                break;
            case 4:
                exibePilha(&pilha);
                break;
            case 5:
                if (consultaTopo(&pilha, &dado) == SUCESSO) {
                    printf("Topo da pilha: CODIGO: %d - PESO: %.2f\n", dado.codigo, dado.peso);
                } else {
                    printf("A pilha esta vazia.\n");
                }
                break;
            case 6:
                printf("Insira o codigo a ser pesquisado: ");
                scanf("%d", &codigoPesquisa);
                if (pesquisa(&pilha, codigoPesquisa, &dado) == SUCESSO) {
                    printf("CODIGO ENCONTRADO: CODIGO: %d - PESO: %.2f\n", dado.codigo, dado.peso);
                } else {
                    printf("CODIGO NAO ENCONTRADO NA PILHA.\n");
                }
                break;
            default:
                if (opcao != 0) {
                    printf("Opcao invalida.\n");
                }
                break;
        }
    } while (opcao != 0);

  
}

