#include "pilhacf.h"
#include <stdio.h>

void criaPilha(Pilha *p) {
    p->topo = -1;
}

int estaVazia(Pilha *p) {
    return (p->topo == -1);
}

int estaCheia(Pilha *p) {
    return (p->topo == MAX_NODOS - 1);
}

int empilha(Pilha *p, int codigo, float peso) {
    if (estaCheia(p)) {
        return PILHA_CHEIA;
    } else {
        p->topo++;
        p->itens[p->topo].codigo = codigo;
        p->itens[p->topo].peso = peso;
        return SUCESSO;
    }
}

int desempilha(Pilha *p, Dado *dado) {
    if (estaVazia(p)) {
        return PILHA_VAZIA;
    } else {
        *dado = p->itens[p->topo];
        p->topo--;
        return SUCESSO;
    }
}

int quantidadeNodos(Pilha *p) {
    return p->topo + 1;
}

void exibePilha(Pilha *p) {
    int i;
    if (estaVazia(p)) {
        printf("A pilha esta vazia.\n");
    } else {
        printf("A pilha possui %d nodos:\n", quantidadeNodos(p));
        for (i = 0; i <= p->topo; i++) {
            printf("CODIGO: %d - PESO: %.2f\n", p->itens[i].codigo, p->itens[i].peso);
        }
    }
}

int consultaTopo(Pilha *p, Dado *dado) {
    if (estaVazia(p)) {
        return PILHA_VAZIA;
    } else {
        *dado = p->itens[p->topo];
        return SUCESSO;
    }
}

int pesquisa(Pilha *p, int codigo, Dado *dado) {
    Pilha aux;
    criaPilha(&aux);

    while (!estaVazia(p)) {
        Dado topo;
        consultaTopo(p, &topo);
        if (topo.codigo == codigo) {
            *dado = topo;
            while (!estaVazia(&aux)) {
                Dado temp;
                desempilha(&aux, &temp);
                empilha(p, temp.codigo, temp.peso);
            }
            return SUCESSO;
        }
        desempilha(p, &topo);
        empilha(&aux, topo.codigo, topo.peso);
    }

    while (!estaVazia(&aux)) {
        Dado temp;
        desempilha(&aux, &temp);
        empilha(p, temp.codigo, temp.peso);
    }

    return DADO_INEXISTENTE;
}

