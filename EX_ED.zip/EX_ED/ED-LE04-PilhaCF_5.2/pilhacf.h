#ifndef PILHA_H
#define PILHA_H

#define SUCESSO 0
#define PILHA_VAZIA 1
#define PILHA_CHEIA 2
#define DADO_INEXISTENTE 3
#define MAX_NODOS 5

typedef struct {
    int codigo;
    float peso;
} Dado;

typedef struct {
    Dado itens[MAX_NODOS];
    int topo;
} Pilha;

void criaPilha(Pilha *p);
int estaVazia(Pilha *p);
int estaCheia(Pilha *p);
int empilha(Pilha *p, int codigo, float peso);
int desempilha(Pilha *p, Dado *dado);
int quantidadeNodos(Pilha *p);
void exibePilha(Pilha *p);
int consultaTopo(Pilha *p, Dado *dado);
int pesquisa(Pilha *p, int codigo, Dado *dado);

#endif

