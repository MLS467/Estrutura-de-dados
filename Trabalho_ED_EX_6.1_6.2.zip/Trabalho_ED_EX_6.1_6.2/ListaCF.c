#include <stdio.h>
#include "ListaCF.h"

void criaLista(ListaCF *lt) {
    lt->n = 0;
}

int incluiNoFim(ListaCF *lt, Dado d) {
    if (lt->n == MAX_NODOS) {
        return LISTA_CHEIA;
    } else {
        lt->v[lt->n] = d;
        lt->n++;
        return SUCESSO;
    }
}

void exibe(ListaCF lt) {
    int i;

    printf("-------------\n");
    printf("LISTA:\n");
    for (i = 0; i < lt.n; i++)
        printf("INFORMACOES DA PESSOA: CODIGO %d: PESO %.3f KG\n", lt.v[i].cod, lt.v[i].peso);
    printf("-------------\n\n");
}

int quantidadeDeNodos(ListaCF lista) {
    if (lista.n == 0) {
        return 0;
    } else {
        return (lista.n);
    }
}

int estaCheia(ListaCF lista) {
    if (lista.n == MAX_NODOS) {
        return 1;
    } else {
        return 0;
    }
}

int estaVazia(ListaCF lista) {
    if (lista.n == 0) {
        return 1;
    } else {
        return 0;
    }
}

int excluiDoFim(ListaCF *lista, Dado *d) {
    if (lista->n == 0) {
        return (LISTA_VAZIA);
    } else {
        *d = lista->v[lista->n - 1];
        lista->n--;
        return (SUCESSO);
    }
}

int incluiNoInicio(ListaCF *lista, Dado d) {
    int i;
    if (lista->n == MAX_NODOS) {
        return (LISTA_CHEIA);
    } else {
        for (i = lista->n; i >= 0; i--)
            lista->v[i + 1] = lista->v[i];
        lista->v[0] = d;
        lista->n++;
        return (SUCESSO);
    }
}

int excluiDoInicio(ListaCF *lista, Dado *d) {
    int i;
    if (lista->n == 0) {
        return (LISTA_VAZIA);
    } else {
        *d = lista->v[0];
        for (i = 1; i <= lista->n; i++)
            lista->v[i - 1] = lista->v[i];
        lista->n--;
        return (SUCESSO);
    }
}

int consultaPorCodigo(ListaCF lista, int cod, Dado *d) {
    int i, c = 0;

    for (i = 0; i < lista.n; i++) {
        if (lista.v[i].cod == cod) {
            d->cod = lista.v[i].cod;
            d->peso = lista.v[i].peso;
            c = 1;
            break;
        }
    }

    if (c == 1) {
        return (SUCESSO);
    } else {
        return (CODIGO_INEXISTENTE);
    }
}

int incluiAntes(ListaCF *lista, int cod, Dado d) {
    int i, j, flag = 0;
    if (lista->n == MAX_NODOS) {
        return (LISTA_CHEIA);
    } else {
        for (i = 0; i <= lista->n; i++) {
            if (lista->v[i].cod == cod) {
                for (j = lista->n; j >= i; j--) {
                    lista->v[j + 1] = lista->v[j];
                }
                lista->v[i] = d;
                lista->n++;
                flag = 1;
                break;
            }
        }
    }

    if (flag == 1) {
        printf("\n\nADICIONADO ANTES DO COD:%d ---> COD:%d E PESO:%.3f KG\n\n", cod, d.cod, d.peso);
        return (SUCESSO);
    } else {
        return (CODIGO_INEXISTENTE);
    }
}

int excluiNodo(ListaCF *lista, int cod, Dado *d) {
    int i, j, flag = 0;

    for (i = 0; i < lista->n; i++) {
        if (lista->v[i].cod == cod) {
            *d = lista->v[i];

            for (j = i + 1; j <= lista->n; j++)
                lista->v[j - 1] = lista->v[j];

            lista->n--;
            flag = 1;
            break;
        }
    }

    if (flag == 1) {
        return (SUCESSO);
    } else {
        return (CODIGO_INEXISTENTE);
    }
}
