/*--------------------------------
* Arquivo: ListaCF.h
*/

#ifndef ListaCF_H
#define ListaCF_H

#define MAX_NODOS 5

#define SUCESSO            0
#define LISTA_VAZIA        1
#define LISTA_CHEIA        2
#define POSICAO_INVALIDA   3
#define CODIGO_INEXISTENTE 4

typedef struct {
	int cod;
	float peso;
} Dado;

typedef struct {
    int n;
	Dado v[MAX_NODOS];
} ListaCF;

/*--------------------------------
*  Prot�tipos das fun��es
*/
void criaLista(ListaCF *lt);
int  incluiNoFim(ListaCF *lt, Dado d);
void exibe(ListaCF lt);
int quantidadeDeNodos(ListaCF lista);
int estaCheia(ListaCF lista);
int estaVazia(ListaCF lista);
int excluiDoFim(ListaCF *lista,Dado *d);
int incluiNoInicio(ListaCF *lista, Dado d);
int excluiDoInicio(ListaCF *lista, Dado *d);
int consultaPorCodigo(ListaCF lista, int cod, Dado *d);
int incluiAntes(ListaCF *lista, int cod, Dado d);
int excluiNodo(ListaCF *lista, int cod,Dado *d);


#endif
