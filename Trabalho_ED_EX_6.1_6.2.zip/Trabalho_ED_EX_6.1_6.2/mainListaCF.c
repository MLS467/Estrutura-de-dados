/*--------------------------------
Maisson 10/09/2023
----------------------------------*/

#include <stdio.h>
#include "ListaCF.h"


main() {
	ListaCF lista;
	Dado dado;
	int cod,i;
	
	criaLista(&lista);
	do {
		printf("0-Fim\n");
		printf("1-Inclui no fim\n");
		printf("2-Exibe lista\n");		
		printf("3-Quantidade de nodos\n");
		printf("4-Exibe situacao da lista\n");
		printf("5-Exclui do fim\n");
		printf("6-Inclui no inicio\n");
		printf("7-Exclui do inicio\n");
		printf("8-Consulta por codigo\n");	
		printf("9-Inclui antes\n");		
		printf("10-Exclui nodo\n\n");	
		printf("Informe a operacao: ");
		scanf("%d",&cod);
		
	switch (cod) {
    case 1:
        printf("\n\nINFORME O CODIGO: ");
        scanf("%d", &dado.cod);
        printf("INFORME O PESO: ");
        scanf("%f", &dado.peso);
        if (incluiNoFim(&lista, dado) == LISTA_CHEIA)
            printf("\n\nERRO: LISTA CHEIA!\n\n");
        else
            printf("\n\nDADOS INCLUIDOS COM SUCESSO!\n\n");
        break;

    case 2:
        exibe(lista);
        break;

    case 3:
        if (quantidadeDeNodos(lista) == 0) {
            printf("\n\nLISTA VAZIA\n\n");
        } else {
            printf("\n\nQUANTIDADE DE NODOS NA LISTA E: (%d)\n\n", lista.n);
        }
        break;

    case 4:
        if (estaCheia(lista) == 1) {
            printf("\n\nLISTA CHEIA\n\n");
        } else if (estaVazia(lista) == 1) {
            printf("\n\nLISTA VAZIA\n\n");
        } else {
            printf("\n\nA LISTA POSSUI 1 OU MAIS NODOS\n\n");
        }
        break;

    case 5:
        if (excluiDoFim(&lista, &dado) == LISTA_VAZIA) {
            printf("LISTA VAZIA\n");
        } else {
            printf("\n\n CODIGO:%d E O PESO %.3f KG, FOI REMOVIDO COM SUCESSO\n\n", dado.cod, dado.peso);
        }
        break;

    case 6:
        printf("INFORME O CODIGO: ");
        scanf("%d", &dado.cod);
        printf("INFORME O PESO: ");
        scanf("%f", &dado.peso);

        if (incluiNoInicio(&lista, dado) == LISTA_CHEIA) {
            printf("\nLISTA CHEIA\n");
        } else {
            printf("\n\nINCLUIDO NO INICIO: ---> CODIGO:%d E PESO:%.3f KG\n\n", dado.cod, dado.peso);
        }
        break;

    case 7:
        if (excluiDoInicio(&lista, &dado) == LISTA_VAZIA) {
            printf("LISTA VAZIA\n");
        } else {
            printf("\n\nEXCLUIDO NO INICIO: ---> CODIGO:%d E PESO:%.3f KG\n\n", dado.cod, dado.peso);
        }
        break;

    case 8:
        printf("BUSCAR CODIGO...\n");
        scanf("%d", &dado.cod);
        if (consultaPorCodigo(lista, dado.cod, &dado) == CODIGO_INEXISTENTE) {
            printf("\n\nCODIGO INEXISTENTE\n\n");
        } else {
            printf("\n\nENCONTRADO: ---> CODIGO:%d E PESO:%.3f KG\n\n", dado.cod, dado.peso);
        }
        break;

    case 9:
        printf("INCLUIR ANTES DO CODIGO...\n");
        scanf("%d", &cod);

        printf("ADICIONAR CODIGO...\n");
        scanf("%d", &dado.cod);

        printf("ADICIONAR PESO...\n");
        scanf("%f", &dado.peso);

        i = incluiAntes(&lista, cod, dado);

        if (i == LISTA_CHEIA) {
            printf("\n\nLISTA CHEIA\n\n");
        } else if (i == SUCESSO) {
            printf("\n\nADICIONADO COM SUCESSO\n\n");
        } else {
            printf("\n\nCODIGO INEXISTENTE\n\n");
        }
        break;

    case 10:
        printf("INCLUIR ANTES DO CODIGO...\n");
        scanf("%d", &cod);

        i = excluiNodo(&lista, cod, &dado);

        if (i == SUCESSO) {
            printf("\n\nEXCLUIDO: ---> CODIGO:%d E PESO:%.3f KG\n\n", dado.cod, dado.peso);
        } else {
            printf("\n\nCODIGO INEXISTENTE\n\n");
        }
        break;
}
} while (cod !=0);

}
